var app = angular.module('session_dashboard', []);
app.controller("session_dashboard_ctrl", function ($scope, $http) {
    $scope.sessionID = sessionStorage.sessionMasterID;
    $scope.sessionData = [];
    $scope.sessionMasterData = {};
    $scope.participantList = [];
    $scope.mostUsedTerms = [
        'doable',
        'idea',
        'get',
        'unique',
        'competitive'
    ];
    $scope.reportType = "t";
    $scope.preConfidenceAverage = 0;
    $scope.postConfidenceAverage = 0;

    $http.get("/getSessionMaster/" + $scope.sessionID).then(function (response) {
        $scope.sessionMasterData = response.data[0];
    });
    $http.get("/getUserSession/" + $scope.sessionID).then(function (response) {
        $scope.sessionData = response.data;
        // console.log($scope.sessionData);
        var sumPreConfidence, sumPostConfidence;
        sumPreConfidence= 0;
        sumPostConfidence = 0;
        for(var i=0; i<response.data.length; i++){
            sumPreConfidence = sumPreConfidence + parseFloat(response.data[i].preConfidencePercent);
            sumPostConfidence = sumPostConfidence + parseFloat(response.data[i].postConfidencePercent);
        }
        if(response.data.length > 0){
            $scope.preConfidenceAverage = sumPreConfidence / response.data.length;
            $scope.postConfidenceAverage = sumPostConfidence / response.data.length;
        }
    
        
    });
    // $http.get('/commentsCount/' + $scope.sessionID + "/Bitcoin").then(function (response) {
    //     response.data;
    // });
    $scope.getTechnologyComments = function (session, technology) {

        for (var i = 0; i < session.technologies.length; i++) {
            var str1 = session.technologies[i].name;
            var str2 = technology.name;
            if (str1 == str2) {
                return session.technologies[i].comments;
            }
        }
        return "";
    };

    $scope.getConfidenceStatus = function (session) {
        if (parseFloat(session.postConfidencePercent) == 0) {
            return 0;
        } else {
            if (parseFloat(session.postConfidencePercent) > 50) {
                return 1;
            } else {
                return -1;
            }
        };
    };

    $scope.back = function () {
        sessionStorage.clear();
        window.location.href = "../view_sessions/view_sessions.html";
    }

    $scope.getURL = function (url) {
        return window.location.protocol + "//" + window.location.hostname + ":" + window.location.port + url;
    }

    $scope.getGraphColor = function(value){
        if(value < 25){
            return 'bg-danger';
        }
         if(value < 50){
            return 'bg-warning';
        }
         if (value < 75){
            return 'bg-info';
        }
         if (value < 100){
            return 'bg-success';
        }
        
    }
});