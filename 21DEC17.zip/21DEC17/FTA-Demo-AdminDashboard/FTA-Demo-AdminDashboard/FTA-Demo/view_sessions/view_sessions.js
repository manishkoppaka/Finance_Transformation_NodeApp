var app = angular.module('view_sessions', []);
app.controller("view_sessions_ctrl", function ($scope, $http) {
    $scope.sessionMasters = [];
    sessionStorage.clear();
    $scope.getParticipantCount = function (index) {
        console.log("Get participantCount");
        $http.get("/getSessionMasterParticipants/" + $scope.sessionMasters[index].sessionMasterID).then(function (response) {
            console.log(response.data);
            $scope.sessionMasters[index].participantCount = response.data;
        });
    }

    $http.get("/getAllSessionMasters").then(function (response) {
        $scope.sessionMasters = response.data;
        for (var i = 0; i < $scope.sessionMasters.length; i++) {
            $scope.getParticipantCount(i);
        }
    });


    $scope.createSession = function () {
        sessionStorage.editMode = true;
        sessionStorage.insertMode = true;

        window.location.href = "../create_session/create_session.html";
    }
    $scope.edit = function (masterId) {
        sessionStorage.editMode = true;
        sessionStorage.insertMode = false;
        sessionStorage.sessionMasterID = masterId;
        window.location.href = "../create_session/create_session.html";
    }

    $scope.share = function (masterId) {
        sessionStorage.editMode = false;
        sessionStorage.insertMode = false;
        sessionStorage.sessionMasterID = masterId;
        window.location.href = "../create_session/create_session.html";
    }

    $scope.delete = function (masterId, index) {
        $http.delete("/deleteSessionMaster/" + masterId).then(function (response) {
            console.log(response.data);
            $scope.sessionMasters.splice(index, 1);
        });
    }

    $scope.viewSessionDashboard = function (masterId) {
        sessionStorage.sessionMasterID = masterId;
        window.location.href = "../session_dashboard/session_dashboard.html";
    }
});