var app = angular.module('create_session', []);
app.controller("create_session_ctrl", function ($scope, $http) {

    if (sessionStorage.editMode == "undefined" || sessionStorage.editMode == "undefined") {
        window.location.href = "../view_sessions/view_sessions.html";
    }
    $scope.technologyList = [];
    $scope.count = 0;
    $scope.selectAllTech = false;
    $scope.editMode = sessionStorage.editMode == "true";
    $scope.insertMode = sessionStorage.insertMode == "true";
    $scope.addTech = '';

    $scope.sessionMaster = {
        company: '', //"IBM",
        industry: '', //"C&IP",
        sessionMasterURL: '',
        technologies: [

        ], //[{"active":"false","name":"Bitcoin","description":"Bitcoin","imgOrigPath":"assets/bitcoin.svg","imgHighlightPath":"assets/bitcoin.activated.svg","placeholder": "How can we help with Bitcoin","comments":""}],
    };


    $http.get("/getAllTechnologies").then(function (response) {
        $scope.technologyList = response.data;
        if (!$scope.insertMode) {
            $http.get("/getSessionMaster/" + sessionStorage.sessionMasterID).then(function (response) {
                $scope.sessionMaster = response.data[0];
                for (var i = 0; i < $scope.sessionMaster.technologies.length; i++) {
                    for (var j = 0; j < $scope.technologyList.length; j++) {
                        if ($scope.sessionMaster.technologies[i].name === $scope.technologyList[j].name) {
                            $scope.technologyList[j].active = "true";
                        }
                    }
                }
            });
        }
    });

    $scope.createSession = function () {
        $scope.sessionMaster.technologies = [];

        for (var i = 0; i < $scope.technologyList.length; i++) {
            if ($scope.technologyList[i].active == "true") {
                $scope.sessionMaster.technologies.push($scope.technologyList[i]);
            }
        }

        if ($scope.insertMode) {
            console.log("Inserting new value.");
            console.log($scope.sessionMaster);
            $http.post("/createSessionMaster", $scope.sessionMaster).then(function (response) {
                $scope.sessionMaster = response.data;
                $scope.editMode = false;
                $scope.insertMode = false;
            });
        } else {
            console.log("Updating Session: " + $scope.sessionMaster.sessionMasterID);
            console.log($scope.sessionMaster);
            $http.post("/updateSessionMaster/" + $scope.sessionMaster.sessionMasterID, $scope.sessionMaster).then(function (response) {
                $scope.sessionMaster = response.data;
                $scope.editMode = false;
                $scope.insertMode = false;
            });
        }
    }

    $scope.createTechnology = function () {
        var data = {
            technologyName: $scope.addTech
        }
        var myData = {
            "active": "false",
            "name": $scope.addTech,
            "description": $scope.addTech,
            "imgOrigPath": "assets/process-automation.svg",
            "imgHighlightPath": "assets/process-automation.activated.svg",
            "placeholder": "How can we help with " + $scope.addTech,
            "comments": ""
        }
        $scope.technologyList.push(myData);
        $http.post("/createTechnology", myData).then((response) => {
            $("#addTechModal").modal('hide');
            $scope.sessionMaster.technologies.push(myData);
            myData.active = "true";
        });
    }

    $scope.selectTechnology = function (tech) {
        if (tech.active == "true") {
            tech.active = "false";
            $scope.count--;
        } else {
            tech.active = "true";
            $scope.count++;
        }
    }

    $scope.selectAll = function () {
        $scope.selectAllTech = !$scope.selectAllTech;
        for (var i = 0; i < $scope.technologyList.length; i++) {
            if ($scope.selectAllTech) {
                $scope.technologyList[i].active = "true";
                $scope.count = $scope.technologyList.length;
            } else {
                $scope.technologyList[i].active = "false";
                $scope.count = 0;
            }
        }
    }

    $scope.edit = function () {
        $scope.editMode = true;
    }

    $scope.back = function () {
        if (!$scope.insertMode && $scope.editMode) {
            $scope.editMode = false;
        } else {
            sessionStorage.editMode = undefined;
            sessionStorage.insertMode = undefined;
            window.location.href = "../view_sessions/view_sessions.html";
        }
    }
    $scope.getURL = function () {
        return window.location.protocol + "//" + window.location.hostname + ":" + window.location.port + $scope.sessionMaster.sessionMasterURL;
    }
});
