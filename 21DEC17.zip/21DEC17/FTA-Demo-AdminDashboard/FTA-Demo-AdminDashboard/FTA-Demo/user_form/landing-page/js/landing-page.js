var app = angular.module('myApp', []);
app.controller('myCtrl', function ($scope, $http) {
    $scope.updateMode = false;
    $scope.session = {
        "sessionMasterID": sessionStorage.sessionMasterID,
        "sessionURL": "",
        "account": "",
        "userId": "",
        "user": "",
        "userEmail": "",
        "company": "",
        "preConfidencePercent": "",
        "preConfidenceComments": "",
        "technologies": [],
        "postConfidencePercent": "",
        "postConfidenceComments": "",
        "runTime": "",
        "execType": "",
        "startTime": "",
        "endTime": "",
        "extraDetails": {
            "rateOfTen": "",
            "comments": "",
            "data": ""
        }
    };

    if (localStorage.sessionId === undefined) {
    } else {
        console.log("Found: "+localStorage.sessionId);
        $http.get("/user-form/getUserSession/" + localStorage.sessionId).then(function (response) {
            if (response.data.length > 0) {
                console.log(response.data[0]);
                $scope.session = response.data[0];
                $scope.updateMode = true;
            }
        });
    }
    $scope.sessionMasterID = sessionStorage.sessionMasterID;

    $scope.addsessions = function () {
        // $http.post('/sessions', $scope.session).then(function (response) {
        //     console.log(response.data);
        //     localStorage.sessionId = response.data._id;
        //     console.log(response.data);
        //     window.location.href = "../confidence-page/confidence-page.html";
        // });
        if($scope.updateMode == true){
            window.location.href = "../confidence-page/confidence-page.html";
        }else{
            console.log("Finding Session");
            $http.get("/user-form/getUserSession/"+$scope.sessionMasterID+"/"+$scope.session.user).then(function(response){
                if (response.data.length > 0){
                    console.log("Session Found..");
                    localStorage.sessionId = response.data[0]._id;
                    window.location.href = "../confidence-page/confidence-page.html";
                }else{
                    console.log("Session Not Found..");
                    $http.post("/user-form/createUserSession", $scope.session).then(function(response){
                        console.log("Session Created..");
                        console.log(response.data);
                        localStorage.sessionId = response.data._id;
                        window.location.href = "../confidence-page/confidence-page.html";
                    });
                }
            });
        }
    };
});
