

/*document.addEventListener("DOMContentLoaded",function(){
var slider = new Slider("#ex13",  {
    formatter: function(value) {
		return value + '%';
	},
    ticks: [0, 25, 50, 75, 100],
    ticks_labels: ['0%', '25%', '50%', '75%', '100%'],
    ticks_snap_bounds: 1     
    });
});*/




if($(window).width() < 767)
{
  $("#ex1").slider({
    formatter: function(value) {
		return value;
	},
      orientation: 'vertical',
	tooltip_position:'bottom',
      tooltip: 'show'
});
} else {
  $("#ex1").slider({
    formatter: function(value) {
		return value;
	},
      orientation: 'horizontal',
	tooltip_position:'top',
      tooltip: 'show',
      ticks_tooltip: true
});

}


// var eltext = document.getElementById('textcomment');
// var length = eltext.getAttribute("maxlength");
// var elcount = document.getElementById('count');
// elcount.innerHTML = length;
// eltext.onkeyup = function () {
//   document.getElementById('count').innerHTML = (length - this.value.length);
// };