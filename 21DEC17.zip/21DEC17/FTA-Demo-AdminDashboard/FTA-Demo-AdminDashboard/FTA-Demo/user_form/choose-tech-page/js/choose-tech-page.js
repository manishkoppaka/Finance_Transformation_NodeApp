    var technologies = [];
    var app = angular.module('myApp', []);
    app.controller('myCtrl', function($scope,$http) {

        //Retrieve all Technologies to display
        $scope.technologyMaster = [];
        // $http.get('/technologies').then(function(response){
        //     $scope.technologyMaster = response.data;
        // });
        $scope.sessionMasterID = sessionStorage.sessionMasterID;
        $http.get('/getSessionMaster/'+$scope.sessionMasterID).then(function(response){
                $scope.technologyMaster = response.data[0].technologies;
            });
        
        //Retrieve User saved information
        $scope.sessionInfo = {};
        $scope.sessionId = localStorage.sessionId;
        
        $http.get('/sessions/' + $scope.sessionId).then(function(response){
            $scope.sessionInfo = response.data;
            $scope.isActive = function(id){
                for (var i = 0; i < $scope.sessionInfo.technologies.length; i++){
                    if($scope.sessionInfo.technologies[i]._id == id){
                        return true;                    
                    }
                }
                return false;
            };
        });
  
        //Define action when user selects technology
        $scope.selectTechnology = function(id){
            if($("#"+id).hasClass("select-cell")){
                $("#"+id).removeClass("select-cell");
                
                for(var i =0; i < $scope.sessionInfo.technologies.length; i++){
                    if(id == $scope.sessionInfo.technologies[i]._id){
                        $scope.sessionInfo.technologies.splice(i,1);
                        break;
                    }
                }
            }else{
                $("#"+id).addClass("select-cell");
                for(var i = 0; i < $scope.technologyMaster.length; i++){
                    if($scope.technologyMaster[i]._id == id){
                        $scope.sessionInfo.technologies.push({"_id": id, "name": $scope.technologyMaster[i].name, "placeholder": $scope.technologyMaster[i].placeholder ,"comments": ""});
                        break;
                    }
                }   
            }
        };     

        $scope.next = function(){
            $http.post('/sessions/' + $scope.sessionId, $scope.sessionInfo).then(function(response){
                window.location.href = "../comments-page/comments-page.html";
            });
        }
    });

// $(document).ready(function(){

//     // var isSelectionMode = false;
//     // var longClicked = false;
//     // var tmr = 0;
    
//     // if(localStorage.getItem('fta-name')){
//     //     $("#display-name").text(localStorage.getItem('fta-name'));
//     // }

//     // for (var i = 0; i < technologies.length; i++){
//     //     if(technologies[i].active){
//     //         isSelectionMode = true;
//     //         enableNext();
//     //         break;
//     //     }
//     // }
//     // /*Handle Long Clicks*/
//     // $(document).on('mousedown','.square-cell',function () {
//     //     var reference = $(this);
//     //     tmr = setTimeout(function () {
//     //                 longClicked = true;
//     //                 if(!isSelected(reference)){
//     //                     reference.addClass("select-cell");
//     //                     isSelectionMode = true;
//     //                     enableNext();
//     //                 }else{
//     //                     reference.removeClass("select-cell");
//     //                     if(getSelectedItems() == 0){
//     //                         isSelectionMode = false;
//     //                         disableNext();
//     //                     }
//     //                 }
//     //             }, 1000);
//     // }).on('mouseup','.square-cell',function () {
//     //     clearTimeout(tmr);
//     // });

//     // $(document).on('click','.square-cell',function(){
        
//     //     if(longClicked){
//     //         longClicked = false;
//     //     }else{
//     //         if(isSelectionMode){
//     //             if(!isSelected($(this))){
//     //                 $(this).addClass("select-cell");
//     //             }else{
//     //                 $(this).removeClass("select-cell");
//     //                 if(getSelectedItems() == 0){
//     //                     isSelectionMode = false;
//     //                     disableNext();
//     //                 }
//     //             }
//     //         }
//     //     }
//     // });
//     // function enableNext(){
//     //     $(".fta-btn-submit").addClass('active');
//     //     $(".fta-btn-submit").removeAttr('disabled');
//     // }
//     // function disableNext(){
//     //     $(".fta-btn-submit").removeClass('active');
//     //     $(".fta-btn-submit").attr('disabled','disabled');
//     // }
//     // function isSelected(ref){
//     //     return ref.hasClass("select-cell");
//     // }

//     // function getSelectedItems(){
//     //     return $(".select-cell").length;
//     // }

//     // $("#btn-next").click(function(){
//     //     for (var i = 0; i < technologies.length; i++){
//     //         technologies[i].active = false;
//     //         $(".select-cell").each(function(){
//     //             if (technologies[i].id == $(this).attr("id")){
//     //                 technologies[i].active = true;
//     //             }
//     //         });
//     //     }
//     //     localStorage.selectedTechnologies = JSON.stringify(technologies);
//     //     window.location.href = "../comments-page/comments-page.html";
//     // });

// });

