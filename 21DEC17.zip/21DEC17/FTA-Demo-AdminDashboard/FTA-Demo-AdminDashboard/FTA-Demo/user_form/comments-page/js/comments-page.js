var app = angular.module('myApp', ['monospaced.elastic']);

app.controller('myCtrl', function($scope, $http) {    
    $scope.sessionInfo = {};
    $scope.sessionId = localStorage.sessionId;
    
    $http.get('/sessions/' + $scope.sessionId).then(function(response){
        $scope.sessionInfo = response.data;
    });

    $scope.next = function(){
        $http.post('/sessions/' + $scope.sessionId, $scope.sessionInfo).then(function(response){
            window.location.href = "../post-confidence-page/post-confidence-page.html";
        });
    }
    
});


$(document).ready(function(){
    // autosize(document.querySelectorAll('textarea'));
    $(".comments textarea").keyup(function(){
        $(this).siblings(".counter").text($(this).val().length+"/"+$(this).attr("maxlength"));
    });
    
});

