var express = require('express');
var app = express();
var mongojs = require('mongojs');
var dbTechnologies = mongojs('test', ['technology']);
var dbSessions = mongojs('test', ['session']);
var dbSessionMaster = mongojs('test', ['sessionMaster']);
var bodyParser = require('body-parser');
var generateSafeId = require('generate-safe-id');
var path = require('path');
var http = require('http');   // added http by manish
const cookieParser = require('cookie-parser');

/**
 * Get port from environment and store in Express.  // added by manish
 */

var port = normalizePort(process.env.PORT || '3000');

const auth = require('./lib/middleware/auth.js');

var server = http.createServer(app);

var urlStatic = "/user_form/";

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: false
}));
app.use(express.static(__dirname + "/FTA-Demo"));

app.use('/view_sessions', auth('admin', 'admin'));


/***************************** 	*/
/** ROUTINGS 					*/
/***************************** 	*/


app.set('port', port);

/**
 * Listen on provided port, on all network interfaces.
 */

server.listen(port);
server.on('error', onError);
server.on('listening', onListening);



/**
 * Normalize a port into a number, string, or false.
 */

function normalizePort(val) {
  var port = parseInt(val, 10);

  if (isNaN(port)) {
    // named pipe
    return val;
  }

  if (port >= 0) {
    // port number
    return port;
  }

  return false;
}

/**
 * Event listener for HTTP server "error" event.
 */

function onError(error) {
  if (error.syscall !== 'listen') {
    throw error;
  }

  var bind = typeof port === 'string' ?
    'Pipe ' + port :
    'Port ' + port;

  // handle specific listen errors with friendly messages
  switch (error.code) {
    case 'EACCES':
      console.error(bind + ' requires elevated privileges');
      process.exit(1);
      break;
    case 'EADDRINUSE':
      console.error(bind + ' is already in use');
      process.exit(1);
      break;
    default:
      throw error;
  }
}

/**
 * Event listener for HTTP server "listening" event.
 */

function onListening() {
  var addr = server.address();
  var bind = typeof addr === 'string' ?
    'pipe ' + addr :
    'port ' + addr.port;
  console.log('Listening on ' + bind);
}



//generating all technologies
app.get('/technologies', function (req, res) {
	console.log("Server received a Get request for Technologies");
	dbTechnologies.technology.find(function (err, docs) {
		// console.log(docs);
		res.json(docs);
	});

});

//generating COunt of all technologies
app.get('/technologiesCount', function (req, res) {
	console.log("Server received a Get Count request for Technologies");
	dbTechnologies.technology.count(function (err, docs) {
		console.log(docs);
		res.json(docs);
	});

});

//Getting Votes of each technology
app.get('/technologyVotes/:id', function (req, res) {
	console.log("Server received a Get Votes request for a specific Technology");
	dbSessions.session.count({ 'technologies.name': req.params.id }, function (err, docs) {
		console.log(docs);
		res.json(docs);
	});

});


//generating a new technology to add to sessionMaster
app.post('/createTechnology', function (req, res) {
	console.log("Server received a post request for Technologies");
	console.log(req.body);
	dbTechnologies.technology.insert(
		{
			active: req.body.active,
			name: req.body.name,
			description: req.body.description,
			imgOrigPath: req.body.imgOrigPath,
			imgHighlightPath: req.body.imgHighlightPath,
			placeholder: req.body.placeholder,
			comments: req.body.comments
		}, function (err, doc) {
			res.json(doc);
			console.log(err);
			console.log(doc);
		});

});

//Getting all sessionMasters
app.get('/genSession', function (req, res) {
	console.log("Server received a Get request for sessionMaster");
	dbSessionMaster.sessionMaster.find(function (err, docs) {
		console.log(docs);
		res.json(docs);
	});
});

//Getting participants of each SessionMaster
app.get('/genSessionParticipants/:id', function (req, res) {
	console.log("Server received a Get Participants request for a specific SessionMaster");
	dbSessions.session.count({ sessionID: req.params.id }, function (err, docs) {
		console.log(docs);
		res.json(docs);
	});

});

//Deleting a new sessionMaster
app.delete('/genSession/:id', function (req, res) {
	console.log(req.params.id);
	dbSessionMaster.sessionMaster.remove({ sessionMasterID: req.params.id }, function (err, doc) {
		res.json(doc);
	});

});

//generating a new sessionMaster
app.post('/createSession', function (req, res) {
	console.log("Server received a Put request for Session Master");
	console.log(req);
	var genid = generateSafeId();
	//res.id(genid);
	dbSessionMaster.sessionMaster.insert(//req.body
		{
			sessionMasterID: genid,   //"zVPkWyvgRW-7pSk0iRzEhdnPcnWfMRi-ZcaPxrHA",
			//sessionMasterURL:  req.body.sessionMasterURL, //"deloitte.com/fta/2ns2sdrecdfsd/hys3gyg/ser/prxy",
			sessionMasterURL: urlStatic + genid,
			company: req.body.company, //"IBM",
			industry: req.body.industry, //"C&IP",
			technologies: req.body.technologies, //[{"active":"false","name":"Bitcoin","description":"Bitcoin","imgOrigPath":"assets/bitcoin.svg","imgHighlightPath":"assets/bitcoin.activated.svg","placeholder": "How can we help with Bitcoin","comments":""}],
			runTime: req.body.runTime, //"1022",
			execType: req.body.execType, //"user:binary",
			startTime: req.body.startTime, //"2012-09-11T02:15:12.356Z",
			endTime: req.body.endTime, //"2012-09-11T02:20:12.356Z",
			extraDetails: req.body.extraDetails //{"rateOfTen":"8","comments":"Very much likely","data":"22504"}
		}, function (err, doc) {
			res.json(doc);
		});

});

//Editing a sessionMaster
app.post('/genSession/:id', function (req, res) {
	console.log(req.params.sessionMasterID);

	dbSessionMaster.sessionMaster.findAndModify({
		query: { sessionMasterID: req.params.id },
		update: {
			$set:
			{
				//		sessionMasterID: genid,   //"zVPkWyvgRW-7pSk0iRzEhdnPcnWfMRi-ZcaPxrHA",
				//sessionMasterURL:  req.body.sessionMasterURL, //"deloitte.com/fta/2ns2sdrecdfsd/hys3gyg/ser/prxy",
				company: req.body.company, //"IBM",
				industry: req.body.industry, //"C&IP",
				technologies: req.body.technologies, //[{"active":"false","name":"Bitcoin","description":"Bitcoin","imgOrigPath":"assets/bitcoin.svg","imgHighlightPath":"assets/bitcoin.activated.svg","placeholder": "How can we help with Bitcoin","comments":""}],
				//runTime:req.body.runTime, //"1022",
				//execType:req.body.execType, //"user:binary",
				startTime: req.body.startTime, //"2012-09-11T02:15:12.356Z",
				endTime: req.body.endTime, //"2012-09-11T02:20:12.356Z",
				//extraDetails:req.body.extraDetails //{"rateOfTen":"8","comments":"Very much likely","data":"22504"}
			}
		}, new: true
	},
		function (err, doc) {
			res.json(doc);
		});

});


app.get('/genSession/:id', function (req, res) {
	console.log("Server received a Get request for SessionMstrDetails");
	dbSessionMaster.sessionMaster.find({ sessionMasterID: req.params.id }, function (err, docs) {
		console.log(docs);
		res.json(docs);
	});

});

//1.	Details of participants for a session-company-technology
app.get('/SessionMstrDetails/:id', function (req, res) {
	console.log("Server received a Get request for SessionMstrDetails");
	dbSessionMaster.sessionMaster.find({ sessionMasterID: req.params.id }, { company: 1, industry: 1, endTime: 1, sessionMasterURL: 1, _id: 0, 'technologies.name': 1 }, function (err, docs) {
		console.log(docs);
		res.json(docs);
	});

});

app.get('/SessionDetails/:id', function (req, res) {
	console.log("Server received a Get request for SessionDetails");
	console.log(req.params.id);
	dbSessions.session.find({ sessionMasterID: req.params.id }, function (err, docs) {
		console.log(docs);
		res.json(docs);
	});
});

app.get('/SessionDetails/:id/:technology', function (req, res) {
	console.log("Server received a Get request for SessionDetails - Technology");
	console.log(req.params.id);
	console.log(req.params.technology);
	dbSessions.session.find({ sessionID: mongojs.ObjectId(req.params.id), 'technologies.name': req.params.technology }, { user: 1, 'technologies.name': 1, 'technologies.comments': 1, preConfidencePercent: 1, postConfidencePercent: 1, preConfidenceCommnents: 1, postConfidenceComments: 1, _id: 0 }, function (err, docs) {
		console.log(docs);
		res.json(docs);
	});
});

//////////////----------
//////////////----------



// to get Total Technologies selected -- Returns All the active technologies for a session


//get all user sessions
app.get('/sessions', function (req, res) {
	console.log("Server received a Get request for session");
	dbSessions.session.find(function (err, docs) {
		console.log(docs);
		res.json(docs);
	});

});

//update or Get a specific user sessions
app.post('/sessions', function (req, res) {
	console.log(req.body);
	dbSessions.session.insert(req.body, function (err, doc) {
		res.json(doc);
	});
	// dbSessions.session.update(
	// 	{ _id: mongojs.ObjectId(req.body._id) },
	// 	req.body,
	// 	{ upsert: true },
	// 	function (err, doc) {
	// 		dbSessions.session.findOne({ user: req.body.user, company: req.body.company }, function (err, doc) {
	// 			res.json(doc);
	// 		});
	// 	});
});

//Get a specific user sessions
app.get('/sessions/:id', function (req, res) {
	var id = req.params.id;

	dbSessions.session.findOne({ _id: mongojs.ObjectId(id) }, function (err, doc) {
		res.json(doc);
	});

});

//Update a specific user sessions
app.post('/sessions/:id', function (req, res) {
	var id = req.params.id;
	console.log(req.body.company);

	dbSessions.session.findAndModify({
		query: { _id: mongojs.ObjectId(req.params.id) },
		//{query:{sessionID:req.params.sessionID},
		update: {
			$set:
			{
				sessionURL: req.body.sessionURL,
				account: req.body.account,
				userId: req.body.userId,
				user: req.body.user,
				userEmail: req.body.userEmail,
				company: req.body.company,
				preConfidencePercent: req.body.preConfidencePercent,
				preConfidenceComments: req.body.preConfidenceComments,
				technologies: req.body.technologies,
				postConfidencePercent: req.body.postConfidencePercent,
				postConfidenceComments: req.body.postConfidenceComments,
				runTime: req.body.runTime,
				execType: req.body.execType,
				startTime: req.body.startTime,
				endTime: req.body.endTime,
				extraDetails: req.body.extraDetails
			}
		}, new: true
	},
		function (err, doc) {
			res.json(doc);
		});
});
/********************************************************* */
/**			    AJAY KHONA                                 */
/********************************************************* */

/***************************** 	*/
/** SESSION DASHBOARD			*/
/***************************** 	*/
app.get('/getSessionMaster/:sessionMasterID', function (req, res) {
	console.log("Server received a Get request for Session Master Details");
	dbSessionMaster.sessionMaster.find({ sessionMasterID: req.params.sessionMasterID }, function (err, docs) {
		console.log(docs);
		res.json(docs);
	});

});

app.get('/getUserSession/:sessionMasterID', function (req, res) {
	console.log("Server received a Get request for User Session");
	dbSessions.session.find({ sessionMasterID: req.params.sessionMasterID }, function (err, docs) {
		console.log(docs);
		res.json(docs);
	});
});

app.get('/getUserSession/:userSessionID/:technology', function (req, res) {
	console.log("Server received a Get request for SessionDetails - Technology");
	dbSessions.session.find({ sessionID: mongojs.ObjectId(req.params.userSessionID), 'technologies.name': req.params.technology }, { user: 1, 'technologies.name': 1, 'technologies.comments': 1, preConfidencePercent: 1, postConfidencePercent: 1, preConfidenceCommnents: 1, postConfidenceComments: 1, _id: 0 }, function (err, docs) {
		console.log(docs);
		res.json(docs);
	});
});

/***************************** 	*/
/** VIEW SESSION MASTERS		*/
/***************************** 	*/
app.get('/getAllSessionMasters', function (req, res) {
	console.log("Server received a Get request for all Session Mastersget");
	dbSessionMaster.sessionMaster.find(function (err, docs) {
		console.log(docs);
		res.json(docs);
	});
});

app.get('/getSessionMasterParticipants/:sessionMasterID', function (req, res) {
	console.log("Server received a Get Participants request for a specific SessionMaster");
	dbSessions.session.count({ sessionMasterID: req.params.sessionMasterID }, function (err, docs) {
		console.log(docs);
		res.json(docs);
	});

});

app.delete('/deleteSessionMaster/:sessionMasterID', function (req, res) {
	console.log("Server received a Delete Session Master Request.");
	dbSessionMaster.sessionMaster.remove({ sessionMasterID: req.params.sessionMasterID }, function (err, doc) {
		// res.json(doc);
		dbSessions.session.remove({sessionMasterID: req.params.sessionMasterID}, function(err, doc){
			res.json(doc);
		});
	});

});

/************************************	*/
/** CREATE/UPDATE SESSION MASTER		*/
/************************************	*/
app.get('/getAllTechnologies', function (req, res) {
	console.log("Server received a Get request for all Technologies");
	dbTechnologies.technology.find(function (err, docs) {
		res.json(docs);
	});

});

app.post('/createSessionMaster', function (req, res) {
	console.log("Server received a create request for Session Master");
	var genid = generateSafeId();
	dbSessionMaster.sessionMaster.insert(//req.body
		{
			sessionMasterID: genid,   //"zVPkWyvgRW-7pSk0iRzEhdnPcnWfMRi-ZcaPxrHA",
			sessionMasterURL: urlStatic + genid,
			company: req.body.company, //"IBM",
			industry: req.body.industry, //"C&IP",
			technologies: req.body.technologies, //[{"active":"false","name":"Bitcoin","description":"Bitcoin","imgOrigPath":"assets/bitcoin.svg","imgHighlightPath":"assets/bitcoin.activated.svg","placeholder": "How can we help with Bitcoin","comments":""}],
			runTime: req.body.runTime, //"1022",
			execType: req.body.execType, //"user:binary",
			startTime: req.body.startTime, //"2012-09-11T02:15:12.356Z",
			endTime: req.body.endTime, //"2012-09-11T02:20:12.356Z",
			extraDetails: req.body.extraDetails //{"rateOfTen":"8","comments":"Very much likely","data":"22504"}
		}, function (err, doc) {
			res.json(doc);
		});
});

//Editing a sessionMaster
app.post('/updateSessionMaster/:sessionMasterID', function (req, res) {
	console.log("Received Update Session Master Request for: "+req.params.sessionMasterID);
	dbSessionMaster.sessionMaster.findAndModify({
		query: { sessionMasterID: req.params.sessionMasterID },
		update: {
			$set:
			{
				company: req.body.company, //"IBM",
				industry: req.body.industry, //"C&IP",
				technologies: req.body.technologies, //[{"active":"false","name":"Bitcoin","description":"Bitcoin","imgOrigPath":"assets/bitcoin.svg","imgHighlightPath":"assets/bitcoin.activated.svg","placeholder": "How can we help with Bitcoin","comments":""}],
				startTime: req.body.startTime, //"2012-09-11T02:15:12.356Z",
				endTime: req.body.endTime, //"2012-09-11T02:20:12.356Z",
			}
		}, new: true
	},
		function (err, doc) {
			res.json(doc);
		});

});

/***************************** 	*/
/** CLIENT USER FORM			*/
/***************************** 	*/
app.get("/user-form/getUserSession/:userSessionID", function(req, res){
	console.log("Received request for fetching User Session by ID: "+req.params.userSessionID);
	dbSessions.session.find({_id: mongojs.ObjectId(req.params.userSessionID)},function(err, doc){
		console.log(doc);
		res.json(doc);
	});
});
app.get("/user-form/getUserSession/:sessionMasterID/:name", function(req, res){
	console.log("Received request for fetching User Session by (SessionMasteID, Name): ("+req.params.sessionMasterID+", ("+req.params.name+")");
	dbSessions.session.find({
		sessionMasterID: req.params.sessionMasterID,
		user: req.params.name
	}, function(err, doc){
		console.log(doc);
		res.json(doc);
	});
});

app.post("/user-form/createUserSession", function(req, res){
	console.log("Received request for creating User Session.");
	console.log(req.body);
	dbSessions.session.insert(req.body, function(err, doc){
		console.log(doc);
		res.json(doc);
	})
});

//////////////// ROutes
app.get("/session_dashboard", function (req, res) {
	res.sendFile(__dirname + "/FTA-Demo/session_dashboard/session_dashboard.html");
});

app.get("/create_session", function (req, res) {
	res.sendFile(__dirname + "/FTA-Demo/create_session/create_session.html");
});

app.get("/view_sessions", function (req, res) {
	res.sendFile(__dirname + "/FTA-Demo/view_sessions/view_sessions.html");
});

app.get(urlStatic + ":url/", function (req, res) {
	res.sendFile(__dirname + "/FTA-Demo/user_form/index.html");
});


app.get("/getSessionByURL" + urlStatic + ":masterId/", function (req, res) {
	dbSessionMaster.sessionMaster.find({ sessionMasterID: req.params.masterId }, function (err, docs) {
		console.log(docs);
		res.json(docs);
	});
});

app.get('/getSession/:id', function (req, res) {
	console.log("Server received a Get request for SessionDetails");
	console.log(req.params.id);
	dbSessions.session.find({ sessionID: mongojs.ObjectId(req.params.id) }, function (err, docs) {
		console.log(docs);
		res.json(docs);
	});
});

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  const err = new Error('Not Found');
  err.status = 404;
  next(err);
});


// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});


/**  commented by manish 
// app.listen(3000);
app.listen(process.env.PORT || 3000, function () {
	console.log("Express server listening on port %d in %s mode", this.address().port, app.settings.env);
});
console.log("Server running on port 3000");

**/

// added exporting by manish
module.exports = app;